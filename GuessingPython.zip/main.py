import random
number = random.randint(1, 100)



print('Hello, I am thinking of a number between 1 and 100.')
print('You will have 10 guesses.')


guessesTaken = 0
while guessesTaken < 11:
  print('Take a guess.\n')
  guess = input()
  guess = int(guess)
  guessesTaken += 1

 

  if guess < number:
    print('Your guess is too low.\n')
    
  if guess > number:
    print('Your guess is too high.\n')

  if guess == number:
    guessesTaken = str(guessesTaken)
    print('You guessed it! You guessed ' + guessesTaken + ' times.')
    break
  
  if guessesTaken == 10:
    print("You're out of guesses.")
    print('The number was ', number)
    break
